package au.com.cba.cct.reststarter.greeting;

public class GreetingService {
}

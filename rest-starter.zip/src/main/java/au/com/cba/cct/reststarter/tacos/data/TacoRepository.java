package au.com.cba.cct.reststarter.tacos.data;

import au.com.cba.cct.reststarter.tacos.Taco;
import org.springframework.data.repository.PagingAndSortingRepository;


public interface TacoRepository extends PagingAndSortingRepository<Taco, Long> {
}

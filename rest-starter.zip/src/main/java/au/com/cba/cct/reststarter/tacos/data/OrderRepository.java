package au.com.cba.cct.reststarter.tacos.data;

import au.com.cba.cct.reststarter.tacos.Order;
import org.springframework.data.repository.CrudRepository;

public interface OrderRepository extends CrudRepository<Order, Long> {
}

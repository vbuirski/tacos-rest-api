package au.com.cba.cct.reststarter.tacos.data;

import au.com.cba.cct.reststarter.tacos.Country;
import au.com.cba.cct.reststarter.tacos.Ingredient;
import org.springframework.data.repository.CrudRepository;

public interface CountryRepository extends CrudRepository<Country, String> {
}

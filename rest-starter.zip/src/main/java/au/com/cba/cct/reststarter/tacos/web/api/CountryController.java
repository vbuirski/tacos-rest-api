package au.com.cba.cct.reststarter.tacos.web.api;

import au.com.cba.cct.reststarter.tacos.Country;
import au.com.cba.cct.reststarter.tacos.Ingredient;
import au.com.cba.cct.reststarter.tacos.data.CountryRepository;
import au.com.cba.cct.reststarter.tacos.data.IngredientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(path="/country", produces="application/json")
@CrossOrigin(origins="*")
public class CountryController {

    private CountryRepository repo;

    @Autowired
    public CountryController(CountryRepository repo) {
        this.repo = repo;
    }

    @GetMapping
    public Iterable<Country> allCountries() {
        return repo.findAll();
    }

}

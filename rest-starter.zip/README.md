# rest-starter

Created by AU\buirsv2

This project is an application skeleton for Contact Center Technology team using Java and Spring Boot. You can use it to quickly clone new projects.

It's a pre-configured Maven project with all required dependencies.

## Getting Started

### Prerequisites
- Git
- JDK 8 or later
- Maven 3.0 or later

### Clone

© 2021 GitHub, Inc.
